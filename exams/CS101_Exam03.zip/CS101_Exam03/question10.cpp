#include <stdio.h>

// TODO: add a prototype for the ipow function

int main(void) {
	// IMPORTANT: do *not* modify the main function
	// in any way.  If you do, you will not receive
	// credit for this question.

	int base, exponent;
	printf("Enter base: ");
	scanf("%i", &base);
	printf("Enter exponent: ");
	scanf("%i", &exponent);

	int result = ipow(base, exponent);
	printf("%i^%i = %i\n", base, exponent, result);

	return 0;
}

// TODO: add a definition of the ipow function
// IMPORTANT: do *not* call the pow function.
// Instead, use a loop.

