#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include "maze_helper.h"
#include "ui.h"

// YOUR TASK: Complete TODO 1 through TODO 4.
// The random maze algorithm and screen drawing are already provided.

// TODO 1: Connect adjacent rooms in BOTH directions.
void connectRooms(Room *a, Room *b, char direction);

// TODO 2: Place one key and one exit in different random rooms.
void placeKeyAndExit(Room *rooms, int total);

// TODO 3: Move the player through a connected pointer.
void movePlayer(Player *player, char direction);

// TODO 4: Collect a key from the current room.
void pickupKey(Player *player);

//Free the dynamically allocated rooms.
void freeMaze(Room *rooms);

int main() {
    srand(time(0));
    printf("===== RANDOM POINTER MAZE =====\n");

    char again = 'Y';
    while (again == 'Y') {
        int rows = readNumber("Rows (2-20): ", 2, 20);
        int cols = readNumber("Columns (2-20): ", 2, 20);
        int total = rows * cols;

        Room *rooms = (Room *)calloc(total, sizeof(Room));
        if (rooms == NULL) {
            printf("Not enough memory.\n");
            return 1;
        }

        for (int i = 0; i < total; i++) {
            rooms[i].id = i + 1;
            rooms[i].row = i / cols;
            rooms[i].col = i % cols;
        }

        generateMaze(rooms, rows, cols, connectRooms);
        placeKeyAndExit(rooms, total);

        Player player;
        player.currentRoom = &rooms[0];
        player.hasKey = 0;
        player.moves = 0;

        showInstructions();
        char command[100];
        while (1) {
            drawMaze(rooms, rows, cols, &player);
            if (player.currentRoom->isExit && player.hasKey) {
                printf("YOU ESCAPED in %d moves!\n", player.moves);
                break;
            }
			
			showInstructions();
            printf("Command: ");
            if (fgets(command, sizeof(command), stdin) == NULL) {
                freeMaze(rooms);
                return 0;
            }
            char action = (char)toupper((unsigned char)command[0]);
            if (action == 'Q') break;
            if (action == 'K') pickupKey(&player);
            else if (action == 'W' || action == 'A' ||
                     action == 'S' || action == 'D') {
                movePlayer(&player, action);
            } else {
                printf("Unknown command.\n");
            }
        }

        freeMaze(rooms);
        printf("Play another random maze? (Y/N): ");
        if (fgets(command, sizeof(command), stdin) == NULL) break;
        again = (char)toupper((unsigned char)command[0]);
    }
    printf("Thanks for playing!\n");
    return 0;
}

// TODO 1: Connect adjacent rooms in BOTH directions.
// direction is 'N', 'S', 'E', or 'W', relative to room a.
void connectRooms(Room *a, Room *b, char direction) {
    // Example: if direction == 'N', a->north = b and b->south = a.
    // Complete all four directions.
}

// TODO 2: Place one key and one exit in different random rooms.
// Do not use the starting room (index 0).
void placeKeyAndExit(Room *rooms, int total) {
    // Hint: rand() % (total - 1) + 1 gives an index from 1 to total-1.
    // Use two different indices.
}

// TODO 3: Move the player through a connected pointer.
void movePlayer(Player *player, char direction) {
    Room *nextRoom = NULL;
    // W = north, S = south, A = west, D = east.
    // If nextRoom is NULL, there is a wall.
    // If nextRoom is the exit and player has no key, refuse entry.
    // Otherwise update currentRoom and increase moves.
}

// TODO 4: Collect a key from the current room.
void pickupKey(Player *player) {
    // If currentRoom->hasKey == 1, remove it and give it to player.
    // Otherwise display a helpful message.
}

//Free the dynamically allocated rooms.
void freeMaze(Room *rooms) {
    free(rooms);
}
