RANDOM POINTER MAZE
====================================

Compile:
macOS/Linux user:
  g++ -std=c++11 -Wall -Wextra main.cpp maze_helper.cpp ui.cpp -o maze
Windows user:
  g++ -std=c++11 -Wall -Wextra main.cpp maze_helper.cpp ui.cpp -o maze.exe

Run on macOS/Linux:
  ./maze
Run on Windows:
  maze.exe

Your task: ONLY edit main.cpp.
Provided files:
  maze_helper.cpp / maze_helper.h - random generation and common structs
  ui.cpp / ui.h - ASCII maze display

TODOs:
  1. connectRooms: connect neighboring rooms in both directions
  2. placeKeyAndExit: choose two distinct non-start rooms
  3. movePlayer: follow directional pointers, block walls and locked exit
  4. pickupKey: transfer key from room to player

The starter compiles but gameplay will not work until TODOs are complete.

Note: The random maze generator depends on connectRooms. Until TODO 1 is
completed, the visual map will show walls between all rooms.
