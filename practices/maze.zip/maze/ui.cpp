#include <stdio.h>
#include "ui.h"
// Instructor-provided: no need to study this file.
void showInstructions() {
    printf("\nW=North  A=West  S=South  D=East\n");
    printf("K=Pick up key  Q=Quit current maze\n");
    printf("P=Player  K=Key  E=Exit  .=Empty\n");
    printf("Find the key, press K, and then reach the exit.\n");
}

void drawMaze(Room *rooms, int rows, int cols, Player *player) {
    printf("\n");
    for (int c = 0; c < cols; c++) printf("+---");
    printf("+\n");
    for (int r = 0; r < rows; r++) {
        printf("|");
        for (int c = 0; c < cols; c++) {
            Room *room = &rooms[r * cols + c];
            char symbol = '.';
            if (room->hasKey) symbol = 'K';
            if (room->isExit) symbol = 'E';
            if (room == player->currentRoom) symbol = 'P';
            printf(" %c %c", symbol, room->east == NULL ? '|' : ' ');
        }
        printf("\n");
        for (int c = 0; c < cols; c++) {
            Room *room = &rooms[r * cols + c];
            printf("+%s", room->south == NULL ? "---" : "   ");
        }
        printf("+\n");
    }
    printf("Room: %d | Moves: %d | Key: %s\n",
           player->currentRoom->id, player->moves,
           player->hasKey ? "YES" : "NO");
    if (player->currentRoom->hasKey) printf("A key is here! Press K.\n");
}
