#ifndef MAZE_HELPER_H
#define MAZE_HELPER_H

struct Room {
    int id;
    int row;
    int col;
    int hasKey;
    int isExit;
    int visited;
    Room *north;
    Room *south;
    Room *east;
    Room *west;
};

struct Player {
    Room *currentRoom;
    int hasKey;
    int moves;
};

// These functions are provided by the instructor.
int readNumber(const char *prompt, int minimum, int maximum);
void generateMaze(Room *rooms, int rows, int cols,
                  void connectRooms(Room *, Room *, char));

#endif
