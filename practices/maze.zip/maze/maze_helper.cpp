#include <stdio.h>
#include <stdlib.h>
#include "maze_helper.h"

// Instructor-provided: no need to study this file.
int readNumber(const char *prompt, int minimum, int maximum) {
    char line[100];
    int value;
    char extra;
    while (1) {
        printf("%s", prompt);
        if (fgets(line, sizeof(line), stdin) == NULL) exit(0);
        if (sscanf(line, " %d %c", &value, &extra) == 1 &&
            value >= minimum && value <= maximum) return value;
        printf("Enter a number between %d and %d.\n", minimum, maximum);
    }
}

// Random depth-first maze generation. Student's connectRooms() creates passages.
void generateMaze(Room *rooms, int rows, int cols,
                  void connectRooms(Room *, Room *, char)) {
    int total = rows * cols;
    Room **stack = (Room **)malloc(total * sizeof(Room *));
    if (stack == NULL) { printf("Not enough memory.\n"); exit(1); }
    int top = 0;
    rooms[0].visited = 1;
    stack[top++] = &rooms[0];

    while (top > 0) {
        Room *current = stack[top - 1];
        Room *neighbors[4];
        char directions[4];
        int count = 0;
        int r = current->row;
        int c = current->col;
        if (r > 0 && !rooms[(r-1)*cols+c].visited) {
            neighbors[count] = &rooms[(r-1)*cols+c]; directions[count++] = 'N';
        }
        if (r+1 < rows && !rooms[(r+1)*cols+c].visited) {
            neighbors[count] = &rooms[(r+1)*cols+c]; directions[count++] = 'S';
        }
        if (c > 0 && !rooms[r*cols+c-1].visited) {
            neighbors[count] = &rooms[r*cols+c-1]; directions[count++] = 'W';
        }
        if (c+1 < cols && !rooms[r*cols+c+1].visited) {
            neighbors[count] = &rooms[r*cols+c+1]; directions[count++] = 'E';
        }
        if (count == 0) { top--; continue; }
        int chosen = rand() % count;
        Room *next = neighbors[chosen];
        connectRooms(current, next, directions[chosen]);
        next->visited = 1;
        stack[top++] = next;
    }
    for (int i = 0; i < total; i++) rooms[i].visited = 0;
    free(stack);
}
