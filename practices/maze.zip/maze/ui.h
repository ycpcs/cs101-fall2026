#ifndef UI_H
#define UI_H
#include "maze_helper.h"
void showInstructions();
void drawMaze(Room *rooms, int rows, int cols, Player *player);
#endif
