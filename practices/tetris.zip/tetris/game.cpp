#include "game.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

int board[HEIGHT][WIDTH];
int score = 0, lines = 0, level = 1, next_type = 0;
Piece current;

void game_init(void) {
    srand((unsigned int)time(NULL));
    memset(board, 0, sizeof(board));
    score = lines = 0;
    level = 1;
    next_type = rand() % NPIECES;
}

static Piece new_piece(int type) {
    Piece p;
    memcpy(p.cells, shapes[type], sizeof(p.cells));
    p.type = type;
    p.x = WIDTH / 2 - 2;
    p.y = -1;
    return p;
}
int spawn_piece(void) {
    current = new_piece(next_type);
    next_type = rand() % NPIECES;
    return is_valid_position(board, current.cells, current.x, current.y);
}
int try_move(int dx, int dy) {
    if (!is_valid_position(board, current.cells, current.x + dx, current.y + dy))
        return 0;
    current.x += dx;
    current.y += dy;
    return 1;
}
void try_rotate(void) {
    if (current.type == 1) return; // Square is unchanged. 
    int rotated[4][4];
    memcpy(rotated, current.cells, sizeof(rotated));
    rotate_piece(rotated);
    //Simplified wall kicks, not the full official SRS rules. 
    const int offsets[] = {0, -1, 1, -2, 2};
    for (int i = 0; i < 5; ++i) {
        if (is_valid_position(board, rotated, current.x + offsets[i], current.y)) {
            memcpy(current.cells, rotated, sizeof(rotated));
            current.x += offsets[i];
            return;
        }
    }
}
int land_piece(void) {
    //A piece that locks above the board ends the game.
    for (int r = 0; r < 4; ++r)
        for (int c = 0; c < 4; ++c)
            if (current.cells[r][c] && current.y + r < 0) return 0;
    lock_piece(board, current.cells, current.x, current.y, current.type);
    int count = clear_lines(board);
    const int points[] = {0, 100, 300, 500, 800};
    score += points[count] * level;
    lines += count;
    level = 1 + lines / 10;
    return spawn_piece();
}
int tick_down(void) {
    if (try_move(0, 1)) return 1;
    return land_piece();
}
