#ifndef GAME_H
#define GAME_H
#include "tetris.h"
extern int board[HEIGHT][WIDTH];
extern int score, lines, level, next_type;
extern Piece current;
void game_init(void);
int spawn_piece(void);
int try_move(int dx, int dy);
void try_rotate(void);
int land_piece(void);
int tick_down(void);
#endif
