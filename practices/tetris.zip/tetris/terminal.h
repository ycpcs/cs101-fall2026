#ifndef TERMINAL_H
#define TERMINAL_H
#include <signal.h>
extern volatile sig_atomic_t interrupted;
int setup_terminal(void);
void restore_terminal(void);
double now_seconds(void);
int read_key(void);
void sleep_frame(void);
#endif
