#include "display.h"
#include "game.h"
#include <stdio.h>
static const char *colors[] = {
    "\033[0m", "\033[46m", "\033[43m", "\033[45m", "\033[42m",
    "\033[41m", "\033[44m", "\033[47m"
};
static void print_cell(int type, int ghost) {
    if (type > 0) printf("%s  \033[0m", colors[type]);
    else if (ghost) printf("\033[2;37m[]\033[0m");
    else printf("  ");
}
void render(int paused, int game_over) {
    int ghost_y = find_ghost_position(board, current.cells, current.x, current.y);
    printf("\033[H");
    printf("  TETRIS IN C                     \n");
    printf("  +--------------------+          \n");
    for (int r = 0; r < HEIGHT; ++r) {
        printf("  |");
        for (int c = 0; c < WIDTH; ++c) {
            int type = board[r][c];
            int ghost = 0;
            int pr = r - current.y, pc = c - current.x;
            if (pr >= 0 && pr < 4 && pc >= 0 && pc < 4 && current.cells[pr][pc])
                type = current.type + 1;
            if (!type) {
                int gr = r - ghost_y;
                if (gr >= 0 && gr < 4 && pc >= 0 && pc < 4 && current.cells[gr][pc])
                    ghost = 1;
            }
            print_cell(type, ghost);
        }
        printf("|");
        if (r == 1) printf("   Score: %d", score);
        if (r == 3) printf("   Lines: %d", lines);
        if (r == 5) printf("   Level: %d", level);
        if (r == 7) printf("   Next:");
        if (r >= 8 && r < 12) {
            printf("   ");
            for (int c = 0; c < 4; ++c)
                print_cell(shapes[next_type][r - 8][c] ? next_type + 1 : 0, 0);
        }
        if (r == 13) printf("   A/D: move");
        if (r == 14) printf("   W: rotate");
        if (r == 15) printf("   S: soft drop");
        if (r == 16) printf("   Space: hard drop");
        if (r == 17) printf("   P: pause");
        if (r == 18) printf("   Q: quit");
        printf("\033[K\n");
    }
    printf("  +--------------------+\033[K\n");
    if (game_over) printf("  GAME OVER! Final score: %d\033[K\n", score);
    else if (paused) printf("  PAUSED - press P to resume\033[K\n");
    else printf("  Clear rows to earn points!\033[K\n");
    printf("\033[J");
    fflush(stdout);
}
