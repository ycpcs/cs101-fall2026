#define _POSIX_C_SOURCE 200809L
#include "terminal.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <sys/select.h>
#include <time.h>
static struct termios original_termios;
static int terminal_active = 0;
volatile sig_atomic_t interrupted = 0;
void restore_terminal(void) {
    if (terminal_active) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &original_termios);
        terminal_active = 0;
    }
    printf("\033[0m\033[?25h\033[?1049l");
    fflush(stdout);
}
static void on_signal(int sig) { (void)sig; interrupted = 1; }
int setup_terminal(void) {
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fprintf(stderr, "Run this program in a macOS Terminal window.\n");
        return 0;
    }
    if (tcgetattr(STDIN_FILENO, &original_termios) != 0) {
        perror("tcgetattr"); return 0;
    }
    struct termios raw = original_termios;
    raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 0;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) != 0) {
        perror("tcsetattr"); return 0;
    }
    terminal_active = 1;
    printf("\033[?1049h\033[?25l");
    fflush(stdout);
    atexit(restore_terminal);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    return 1;
}
double now_seconds(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1000000000.0;
}
int read_key(void) {
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    struct timeval timeout = {0, 0};
    if (select(STDIN_FILENO + 1, &fds, NULL, NULL, &timeout) <= 0) return -1;
    unsigned char ch;
    return read(STDIN_FILENO, &ch, 1) == 1 ? (int)ch : -1;
}
void sleep_frame(void) {
    struct timespec ts = {0, 16000000L};
    nanosleep(&ts, NULL);
}

