#ifndef TETRIS_H
#define TETRIS_H
#define WIDTH 10
#define HEIGHT 20
#define NPIECES 7

typedef struct { int cells[4][4]; int type; int x, y; } Piece;
extern const int shapes[NPIECES][4][4];
int is_valid_position(const int grid[HEIGHT][WIDTH], const int cells[4][4], int x, int y);
void rotate_piece(int cells[4][4]);
void lock_piece(int grid[HEIGHT][WIDTH], const int cells[4][4], int x, int y, int type);
int clear_lines(int grid[HEIGHT][WIDTH]);
int find_ghost_position(const int grid[HEIGHT][WIDTH], const int cells[4][4], int x, int y);
#endif
