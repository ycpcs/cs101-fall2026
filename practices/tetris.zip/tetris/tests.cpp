#include "tetris.h"
#include <stdio.h>
#include <string.h>

static int passed = 0;
static int failed = 0;

#define CHECK(condition) do { \
    if (condition) { \
        ++passed; \
    } else { \
        ++failed; \
        printf("FAIL: %s (line %d)\n", #condition, __LINE__); \
    } \
} while (0)

static void test_valid() {
    int b[HEIGHT][WIDTH] = {};
    int p[4][4] = {}; p[0][0] = 1;
    CHECK(is_valid_position(b,p,0,0) == 1);
    CHECK(is_valid_position(b,p,-1,0) == 0);
    CHECK(is_valid_position(b,p,0,HEIGHT) == 0);
    CHECK(is_valid_position(b,p,0,-1) == 1);
    b[0][0] = 5;
    CHECK(is_valid_position(b,p,0,0) == 0);
}
static void test_rotate() {
    int p[4][4] = {}; p[1][0] = 1;
    rotate_piece(p);
    CHECK(p[0][2] == 1);
    int count=0; for(int r=0;r<4;r++)for(int c=0;c<4;c++)count+=p[r][c];
    CHECK(count==1);
    for(int k=0;k<3;k++)rotate_piece(p);
    CHECK(p[1][0]==1);
}
static void test_lock() {
    int b[HEIGHT][WIDTH] = {};
    int p[4][4] = {}; p[0][0]=1; p[1][1]=1;
    lock_piece(b,p,3,4,2);
    CHECK(b[4][3]==3 && b[5][4]==3 && b[4][4]==0);
}
static void test_clear() {
    int b[HEIGHT][WIDTH] = {};
    b[HEIGHT-3][2]=7;
    for(int c=0;c<WIDTH;c++) { b[HEIGHT-1][c]=1; b[HEIGHT-2][c]=2; }
    CHECK(clear_lines(b)==2);
    CHECK(b[HEIGHT-1][2]==7 && b[HEIGHT-1][1]==0);
    CHECK(b[HEIGHT-2][2]==0);
}
static void test_ghost() {
    int b[HEIGHT][WIDTH] = {};
    int p[4][4] = {}; p[0][0]=1;
    CHECK(find_ghost_position(b,p,0,0)==HEIGHT-1);
    b[10][0]=3;
    CHECK(find_ghost_position(b,p,0,0)==9);
}
int main() {
    test_valid(); test_rotate(); test_lock(); test_clear(); test_ghost();
    printf("\nTests passed: %d\n", passed);
    printf("Tests failed: %d\n", failed);
    if (failed == 0) puts("All basic tests passed!");
    return failed > 0 ? 1 : 0;
}
