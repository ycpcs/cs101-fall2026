#include "game.h"
#include "display.h"
#include "terminal.h"
#include <stdio.h>

int main(void) {
    if (!setup_terminal()) return 1;
    game_init();
    int alive = spawn_piece();
    int paused = 0, quit = 0;
    double last_fall = now_seconds();
    render(paused, !alive);
    while (!quit && !interrupted) {
        int key;
        while ((key = read_key()) != -1) {
            if (key == 'q' || key == 'Q') { quit = 1; break; }
            if (key == 'p' || key == 'P') {
                paused = !paused;
                last_fall = now_seconds();
                continue;
            }
            if (paused || !alive) continue;
            switch (key) {
                case 'a': case 'A': try_move(-1, 0); break;
                case 'd': case 'D': try_move(1, 0); break;
                case 'w': case 'W': try_rotate(); break;
                case 's': case 'S':
                    if (try_move(0, 1)) ++score;
                    else alive = land_piece();
                    last_fall = now_seconds();
                    break;
                case ' ':
                    {
                        int landing = find_ghost_position(board, current.cells, current.x, current.y);
                        score += 2 * (landing - current.y);
                        current.y = landing;
                        alive = land_piece();
                        last_fall = now_seconds();
                    }
                    break;
                default: break;
            }
        }
        if (!paused && alive) {
            double interval = 0.75 - (level - 1) * 0.055;
            if (interval < 0.09) interval = 0.09;
            double now = now_seconds();
            if (now - last_fall >= interval) {
                alive = tick_down();
                last_fall = now;
            }
        }
        render(paused, !alive);
        sleep_frame();
    }
    restore_terminal();
    if (!interrupted) printf("Thanks for playing! Final score: %d\n", score);
    return 0;
}
