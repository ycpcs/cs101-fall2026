TETRIS

YOUR TASK

Complete five unfinished functions to make the provided Tetris game work correctly. The game loop, display, controls, scoring, and piece definitions are already provided.

Use arrays, pointers, functions, loops, and conditional statements.

Only edit tetris.cpp. Do not use classes, vectors, templates, dynamic memory, or external libraries.

GETTING STARTED
1. Open Terminal and navigate to the project folder.
2. Compile the game using: make
3. Run the game using: ./tetris
4. Open tetris.cpp and locate the five TODO functions.
5. Complete the functions in the order below.
The program compiles before you finish, but the game will not work correctly until the functions are implemented.


Game board: grid[HEIGHT][WIDTH]

HEIGHT = 20, WIDTH = 10
0 = empty; nonzero = occupied

Tetris piece: cells[4][4]

0 = empty; 1 = occupied

The position (x,y) represents the top-left corner of the piece's 4x4 matrix.

A piece cell at cells[r][c] maps to grid[y+r][x+c].

x increases rightward, and y increases downward. Pieces may start partly above the visible board.

TASK 1: CHECK FOR COLLISIONS

Function: is_valid_position

Determine whether a piece can occupy a given position.
1. Examine all occupied piece cells using nested loops.
2. Calculate their board coordinates.
3. Return 0 if any occupied cell is beyond the left/right edge, below the bottom, or overlaps another block.
4. Allow occupied cells above the board.
5. Return 1 if the position is valid.
6. Do not modify either array.
Think about: Empty cells in the 4x4 piece should not cause collisions.

TASK 2: ROTATE A PIECE

Function: rotate_piece

Rotate the entire 4x4 matrix 90 degrees clockwise.
1. Use a temporary 4x4 array.
2. Apply the mapping: old[r][c] becomes new[c][3-r].
3. Copy the rotated values back into the original array.
4. Do not modify the board.
Test: Four clockwise rotations should restore the original piece.

TASK 3: LOCK A PIECE

Function: lock_piece

Make a landed piece permanent on the board.
1. Examine all occupied piece cells.
2. Calculate their board coordinates.
3. For positions inside the board, store type + 1.
4. Ignore cells outside the board, including those above the top.
5. Do not overwrite board cells with zeros.
Example: If type = 2, occupied cells should be stored as 3.

TASK 4: CLEAR COMPLETED LINES

Function: clear_lines

Remove rows where all 10 cells are nonzero.
1. Check each row to determine whether it is full.
2. Shift all rows above a completed row downward by one.
3. Fill the new top row with zeros.
4. Return the total number of cleared rows.
5. Handle multiple adjacent completed rows correctly.
Think about: After shifting rows, the same row index contains different data. Make sure you check it again.

Test: Two consecutive full bottom rows should both disappear, and the function should return 2.

TASK 5: FIND THE GHOST POSITION

Function: find_ghost_position

Find the lowest valid landing position without moving the actual piece.
1. Start at the supplied y position.
2. Keep x unchanged.
3. Repeatedly test one row lower using is_valid_position.
4. Stop when the next position is invalid.
5. Return the last valid y value.
6. Do not modify either array.
Test: On an empty board, a single occupied cell at cells[0][0], starting at (0,0), should land at y = 19.

BUILD AND TEST

After making changes, use these Terminal commands:

make
make test
./tetris

To clean and rebuild:

make clean
make

The provided tests check basic functionality, but you should also test edge cases yourself.

Make sure pieces cannot move through walls, rotations work correctly, landed pieces remain on the board, completed rows disappear, and the ghost position predicts the correct landing location.

OPTIONAL EXTRA CHALLENGES
1. Rotation Counter: Track how many rotations the player makes.
2. Ghost Display: Show the ghost piece using a different symbol or color.
3. Smart Placement: Suggest a landing position based on board height and holes.
4. Pointer Challenge: Rewrite one function using pointer arithmetic instead of [row][col].

HAVE FUN!

Once all five functions work, run ./tetris and play your completed game.
