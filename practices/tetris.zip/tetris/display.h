#ifndef DISPLAY_H
#define DISPLAY_H
void render(int paused, int game_over);
#endif
