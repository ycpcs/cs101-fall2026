#include "tetris.h"
#include <string.h>

const int shapes[NPIECES][4][4] = {
    {{0,0,0,0},{1,1,1,1},{0,0,0,0},{0,0,0,0}},
    {{0,1,1,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},
    {{0,1,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
    {{0,1,1,0},{1,1,0,0},{0,0,0,0},{0,0,0,0}},
    {{1,1,0,0},{0,1,1,0},{0,0,0,0},{0,0,0,0}},
    {{1,0,0,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}},
    {{0,0,1,0},{1,1,1,0},{0,0,0,0},{0,0,0,0}}
};


//  Complete the five functions below.
//  Do not modify tetris.h.
//  The board uses grid[row][column] and has HEIGHT rows, WIDTH columns.
//  A zero cell is empty; a nonzero cell is occupied.
//  The 4x4 cells array represents the current piece (0 or 1).
//  Its top-left corner is at board coordinate (x, y).


//TODO 1: Collision checking
//   Return 1 only if every occupied piece cell can fit at (x, y).
//   For each cells[r][c] != 0, board position is (x+c, y+r).
//   - Reject occupied cells with x+c outside [0, WIDTH-1].
//   - Reject occupied cells with y+r >= HEIGHT.
//   - Reject collisions with nonzero grid cells when y+r >= 0.
//   - IMPORTANT: y+r < 0 is allowed (pieces may spawn above the board).
//   - Ignore empty piece cells, even if their coordinates are outside.
//   Do not modify grid or cells.
//
int is_valid_position(const int grid[HEIGHT][WIDTH], const int cells[4][4], int x, int y) {
    
    //TODO 1
    
    return 1;
}

// TODO 2: Rotate clockwise
//   Modify cells IN PLACE so the entire 4x4 matrix rotates 90 degrees
//   clockwise. The cell formerly at [r][c] moves to [c][3-r].
//   Hint: use a temporary 4x4 array, then copy it back.
//   Do not rotate the board, and do not change piece coordinates.
//   Example: a cell at [1][0] moves to [0][2].

void rotate_piece(int cells[4][4]) {
    
    // TODO 2
}

// TODO 3: Lock a landed piece into the board
//   For every occupied cells[r][c], write type+1 into
//  grid[y+r][x+c] IF that board coordinate is in bounds.
//   - Ignore empty piece cells.
//   - Ignore occupied piece cells above the board (negative row).
//   - Do not overwrite unrelated board cells.
//   Why type+1? Zero means empty, while types are numbered from zero.

void lock_piece(int grid[HEIGHT][WIDTH], const int cells[4][4], int x, int y, int type) {
   
    // TODO 3
}

// TODO 4: Remove completed rows
//   A row is complete when ALL WIDTH entries are nonzero.
//   For each complete row:
//   - Remove it and move every row above it down by one position.
//   - Fill the new top row with zeros.
//   - Count how many rows were removed and return the count.
//   IMPORTANT: consecutive completed rows must both be removed.
//   Hint: scan from the bottom; after shifting, inspect the SAME
//   row index again because a different row just moved there.
//   Preserve all values in rows that are not cleared.

int clear_lines(int grid[HEIGHT][WIDTH]) {
    
    //TODO 4
    return 0;
}

// TODO 5: Ghost piece / landing prediction
//   Return the LOWEST legal y-coordinate for the piece at x,
//   starting from its current y and moving downward one row at a time.
//   Do NOT change the grid, cells, or original piece coordinates.
//  Hint: call is_valid_position(grid, cells, x, candidate_y).
//   Assume the initial position is legal.
//
int find_ghost_position(const int grid[HEIGHT][WIDTH], const int cells[4][4], int x, int y) {
    
    
    // TODO 5
    return 1;
}
