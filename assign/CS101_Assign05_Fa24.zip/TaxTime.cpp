// CS101 Assignment 5 TaxTime - Fall 2024
#include <stdio.h>

// TODO: Declare Person struct


// TODO: Add calcTaxes function prototype

int main() {
	double t_oblig = 0.0;;

	// TODO: Declare Person variable and get user input
	
	// TODO: Call calcTaxes function to set t_oblig
	
	// Print tax obligation
	printf("Tax obligation: $%.2lf\n", t_oblig);
	
	return 0;
}

// TODO: Add calcTaxes function definition (print taxable income and tax rate)