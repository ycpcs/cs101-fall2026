// CS101 Assignment 5 HitBox - Fall 2024
#include <stdio.h>
#include <assert.h>
#include <math.h>

#define EPS 0.01

// Rect struct definition
struct Rect {
	double x;
	double y;
	double width;
	double height;
};

double hitbox(Rect r1, Rect r2);

int main() {

	// DO NOT MODIFY main in ANY WAY
	Rect r1 = {-4.0, -0.5, 4.5, 3.2};
	Rect r2 = {-0.2, -1.8, 6.7, 2.9};
	assert(abs(1.12 - hitbox(r1,r2)) < EPS);

	Rect r3 = {-0.2, -1.8, 6.7, 2.9};
	Rect r4 = {-4.0, -0.5, 4.5, 3.2};
	assert(abs(1.12 - hitbox(r3,r4)) < EPS);

	Rect r5 = {-4.2, -0.2, 3.4, 2.5};
	Rect r6 = {0.8, 1.3, 3.6, 1.2};
	assert(abs(0.0 - hitbox(r5,r6)) < EPS);

	Rect r7 = {-1.0, -1.0, 2.0, 2.0};
	Rect r8 = {-1.5, -0.4, 5.2, 0.8};
	assert(abs(1.6 - hitbox(r7,r8)) < EPS);

	Rect r9 = {0.3, -0.3, 0.8, 1.0};
	Rect r10 = {0.0, -1.4, 8.3, 7.8};
	assert(abs(0.8 - hitbox(r9,r10)) < EPS);

	Rect r11 = {3.7, 0.5, 2.8, 2.0};
	Rect r12 = {4.4, -1.4, 5.2, 10.1};
	assert(abs(4.2 - hitbox(r11,r12)) < EPS);
	
	printf("All tests passed!\n");
	
	return 0;
}

double hitbox(Rect r1, Rect r2) {
	double area = 0.0;
	
	// TODO: Compute overlap area	
	
	return area;
}