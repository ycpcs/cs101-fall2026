// CS101 Assignment 6 - Fall 2024
#ifndef PLAYER_H
#define PLAYER_H

#include <stdlib.h>
#include "Const.h"
#include "Console.h"

// TODO: Add player struct

// TODO: Add player accessor function prototypes

#endif // PLAYER_H
