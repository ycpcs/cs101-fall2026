#include <stdio.h>
#define NUM_COLUMNS 10

double computeAverage(double array[], int size);
void negateElements(double array[], int size);
double maximumRowSum(double table[][NUM_COLUMNS], int numRows);


int main(void)
{
	int size = 4;
	
	double myArray[size] = {1, 2, 3, 4};
	negateElements(myArray, size);
	printf("In the main:\n");
    printf("1st: %f\n", myArray[0]); // -1
    
    
    
    double twoDarray[2][NUM_COLUMNS] = {...};
    
    maximumRowSum(twoDarray, 2);
    
    
	return 0;
}
//The array is passed by reference (pointer)
//the address of the first element in the array
void negateElements(double array[], int size)
{
    for (int i = 0; i < size; i++) {
        array[i] *= -1;}
    printf("In the function:\n");
    printf("1st: %f\n", array[0]);  // -1
}

double computeAverage(const double array[], int size)
{
    double sum = 0.0;
    for (int i = 0; i < size; i++) {
        sum += array[i]; 	
    }
    return sum / size;   }


double maximumRowSum(double table[][NUM_COLUMNS], int numRows)
{
    int j, i;
    double sum, max;

    for (j = 0; j < numRows; j++) {
        sum = 0.0;
        for (i = 0; i < NUM_COLUMNS; i++) {
            sum += table[j][i];
        }
        if (j == 0 || sum > max) {
            max = sum;
        }
    }
    return max;
}





