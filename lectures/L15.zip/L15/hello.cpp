#include <stdio.h>


int main(void)
{
	//declare a pointer named p to store
	//the address of an integer variable
	int *p;
	
	//declare an integer variable
	int a;
	
	//store the address of a into the pointer p
	//p->a
	p = &a; //&a gives you the address of a
	
	a = 42; //store a value using variable name
	
	*p = 42; //store a value by using the address of the variable
	
	//p: the address of the variable that p points to
	//*p: the variable that p points to, a
	//&p: the address of p
	
	a = 101;
	printf("*p = %d\n", *p); //? 101
	
	
	int *q;
	
	q = p; 
	
	*q = 12;
	printf("a = %d\n", a); //? 12
	printf("*p = %d\n", *p); //? 12
	
	
	// printf("p = %p\n", p);
	// 	printf("the address of a: %p\n", &a);
	// 	printf("*p = %d\n", *p);
	// 	printf("&p = %p\n", &p);
	
	
	

	int x = 5;
	int y = 10;
	int z = 50;
	x = timesThree(x);
	y = timesThree(y);
	
	timesThreewithPointer(&x, &y, &z);
	
	scanf(..., &__);
	
    return 0;
}



void timesThreewithPointer(int *p, int *p1, int *p2){

	*p = *p * 3;
	*p1 = *p1 * 4;
	*p2 = *p2 * 5;
}

int timesThree(int x){
	x = x * 3;
	//x = ? 15
	return x;
}




