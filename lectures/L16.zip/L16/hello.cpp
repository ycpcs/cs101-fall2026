#include <stdio.h>


//define a struct type named Point
//then you can use Point as a datatype just like int, double, char...
struct Point{	

	//define some fields
	double x; 
	double y; 
	
};

//you can use a defined struct type as function's return type
//then this will return a variable that stores a Point
struct Point makePoint(double p_x, double p_y);

void makePointwithPointer(Point *p, double p_x, double p_y);

int main(void)
{
	
	int a;
	
	Point p = makePoint(2.3, 4.5);
	
	Point p1;
	makePointwithPointer(&p1, 2.4, 4.5);
 
    return 0;

}

void printPoint(Point p){

	printf("x = %f\n", p.x);
	printf("y = %f\n", p.y);
}

//Preferred, why?




void printPoint(const Point *p){
	
	printf("x = %f\n", p->x);
	printf("y = %f\n", p->y);
}









void makePointwithPointer(Point *p, double p_x, double p_y){	
	
	p->x = p_x; 
	p->y = p_y;	
}


//function definition
struct Point makePoint(double p_x, double p_y){

	Point p;
	p.x = p_x;
	p.y = p_y;
	
	return p;
}











