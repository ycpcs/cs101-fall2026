#include <stdio.h>


struct Location{
	int row;
	int col;
};

struct Player{
	Location loc;
	int hitPoints;
};

void moveLocation(Location *loc, int dx, int dy);

void movePlayer(Player *p, int dx, int dy);

int main(void)
{
	
	Location loc = {1,2};
	moveLocation(&loc, 3, 4);
	
	Player p = {{1,2}, 0};
	
	movePlayer(&p, 4, 5);
 
    return 0;

}

void moveLocation(Location *loc, int dx, int dy){
	
	//Location l;
	//l.row: access row field of l (l is a variable)
	
	//loc is a pointer
	//access the row field of Location
	loc->row += dx;
	loc->col += dy;

}

void movePlayer(Player *p, int dx, int dy){
	//p->loc	
	//Address of player's location?
	//loc field of the player
	moveLocation(&(p->loc), 4, 5);
	
	//access the row field of the player
	p->loc.row
	p->loc.col
}









